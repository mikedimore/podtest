//
//  PrizeOut.h
//  PrizeOut
//
//  Created by Mike Dimore on 7/15/19.
//  Copyright © 2019 Prize Out. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PrizeOut.
FOUNDATION_EXPORT double PrizeOutVersionNumber;

//! Project version string for PrizeOut.
FOUNDATION_EXPORT const unsigned char PrizeOutVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PrizeOut/PublicHeader.h>


